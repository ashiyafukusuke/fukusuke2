# イタキモ サイトリニューアル 実装キット

1. このフォルダごとリポジトリの横に置く（または中にコピーする）
2. Antigravityに `PROMPT.md` の本文を貼り付け、このフォルダの場所を伝える
3. 本番公開の前に、スマホとPCで実際に見て確認する

## 中身
- PROMPT.md … Antigravityへの指示
- reference/top.html, reference/first.html … 完成見本（ローカルで開く場合、画像は public/ 配下を参照）
- public/images/ … 写真7枚（hero-pc, hero-sp, reason-01〜03, owner, first-chair）
- public/logo/ … ロゴ（横組・サイト用）、バクのマーク

## 公開前に福助さんが確認すること
- 写真に写っている方（足のモデル）の掲載同意
- STORES予約ページの「初回お試し」表記を「左足トライアル」に揃える
